# this command shows computer name.
whoami |more >> pc-information.txt
# this command shows username.
echo $USER |more >> pc-information.txt
# this command shows current current working director.
pwd |more >> pc-information.txt
# this command shows running applications and services.
ps aux |more >> pc-information.txt
# this command shows  current opened ports.
cat /etc/services >> pc-information.txt
# this command shows current hostname. 
hostname |more >> pc-information.txt
# this command shows IP address. 
ip address show >> pc-information.txt
# this command shows network adapters. 
sudo lshw -class network -short |more >> pc-information.txt
# this command shows available memory space.
free -m |more >> pc-information.txt
# this command shows available hardisk space.
df |more >> pc-information.txt